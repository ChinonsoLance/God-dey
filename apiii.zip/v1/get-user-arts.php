<?php
require "variables.php";
cors();
$wallet=$_REQUEST['address'];

$get_arts = mysqli_query($conn, "SELECT * FROM arts WHERE user_id='$wallet'");
$full_array=array();
if(mysqli_num_rows($get_arts)>0){
    while($art=mysqli_fetch_assoc($get_arts)){
        $name=$art['name'];
        $price=$art['price'];
        $file=$art['file'];
        $status=$art['status'];
        $id=$art['id'];

        $array = array(
            "status"=>$status,
            "name"=>$name,
            "price"=>$price,
            "file"=>$file,
            "id"=>$id,
            );
            array_push($full_array, $array);
    }
    
   

    
}
else{
    $full_array = array();
}

echo json_encode($full_array);

?>