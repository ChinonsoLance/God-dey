<?php
require "variables.php";
cors();
//print_r($_POST);
$address = mysqli_real_escape_string($conn,$_POST['address']);
$fee = doubleval(mysqli_real_escape_string($conn,$_POST['price']));

$get_user=mysqli_query($conn, "SELECT * FROM users WHERE wallet='$address'");
if(mysqli_num_rows($get_user)>0){
    $row=mysqli_fetch_assoc($get_user);

    $balance=$row['balance'];
}

$new_balance = $balance-$fee;

$update_balance = mysqli_query($conn, "UPDATE users SET balance='$new_balance' WHERE wallet='$address'");


$update = mysqli_query($conn, "INSERT INTO withdrawals(user_id, amount)VALUES('$address','$fee')");

if($update){
    $array = array(
        "success"=>true,
        "message"=>""
    );
}
else{
    $array = array(
        "success"=>false,
        "message"=>"An error occurred"
    );
}

echo json_encode($array);