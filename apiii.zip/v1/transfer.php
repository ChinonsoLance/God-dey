<?php
require "variables.php";
cors();
//echo json_encode($_POST);
$amount = mysqli_real_escape_string($conn, $_POST['amount']);
$to = mysqli_real_escape_string($conn, $_POST['address']);
$from = mysqli_real_escape_string($conn, $_POST['from']);


$get_from_details = mysqli_query($conn, "SELECT balance FROM users WHERE wallet = '$from'");
$from_details = mysqli_fetch_assoc($get_from_details);
$from_balance = $from_details['balance'];

$get_to_details = mysqli_query($conn, "SELECT balance FROM users WHERE wallet = '$to'");
$to_details = mysqli_fetch_assoc($get_to_details);
$to_balance = $to_details['balance'];

$new_from =  $from_balance-$amount;
$new_to = $to_balance+$amount;
if($new_from >= 0){
    $update_from = mysqli_query($conn, "UPDATE users SET balance = '$new_from' WHERE wallet = '$from'");
    $update_to = mysqli_query($conn, "UPDATE users SET balance = '$new_to' WHERE wallet = '$to'");
    if($update_from && $update_to){
        $array = array(
            "success"=>true,
            "message"=>""
        );
    }
    else{
        $array = array(
            "success"=>false,
            "message"=>"An error occurred "
        );
    }
}
else{
    $array = array(
        "success"=>false,
        "message"=>"Insufficient Balance"
    );
}


echo json_encode($array);