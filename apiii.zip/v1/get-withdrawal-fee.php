<?php
require "variables.php";
cors();



$select = mysqli_query($conn, "SELECT withdrawal_fee FROM settings WHERE id='1'");

if(mysqli_num_rows($select)>0){
    $setting = mysqli_fetch_assoc($select);
    $withdraw_fee=$setting['withdrawal_fee'];
}


echo $withdraw_fee;