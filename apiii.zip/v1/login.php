<?php
require "variables.php";
cors();
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$results = array();

$get_credentials = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
if(mysqli_num_rows($get_credentials)>0){
    $user=mysqli_fetch_assoc($get_credentials);
    $dbpassword = $user['password'];
    if(password_verify($password,$dbpassword)){
        $wallet = $user['wallet'];
        $results = array(
            "loggedIn"=>true,
            "email"=>$email,
            "wallet"=>$wallet
            );
    }
    else{
        $results = array(
            "loggedIn"=>false,
            "message"=>"Invalid credentials"
                ); 
    }
    
}
else{
   $results = array(
            "loggedIn"=>false,
            "message"=>"Invalid credentials"
                ); 
}

echo json_encode($results);
?>