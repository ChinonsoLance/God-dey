<?php
if($_SERVER['SERVER_NAME']=="localhost" || $_SERVER['SERVER_NAME']=="127.0.0.1" || $_SERVER['SERVER_NAME']=="192.168.135.16" ){
    $host="localhost";
    $username="root";
    $password="";
    $dbname="trevomint"; 
}
else if($_SERVER['SERVER_NAME']=="0.0.0.0"){
    $host="127.0.0.1";
    $username="root";
    $password="root";
    $dbname="coinmark_investorm";
}
else{
    $host="localhost";
    $username="pictora3_newart";
    $password="Jesusislord123$";
    $dbname="pictora3_newart";
}

$sitename="PictoralLab";
$admin_email="info@pictorallab.com";

$conn=mysqli_connect($host,$username,$password,$dbname);

if(!$conn){
    $response = array(
        "error" => "yes",
        "errorMsg" => "Invalid db details"
    );

   // echo json_encode($response);
}


?>