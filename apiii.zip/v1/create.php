<?php
require "variables.php";
cors();
//echo ("entries". json_encode($_POST['data']));

$data = json_encode($_POST);
//print_r($data);
$wallet = mysqli_real_escape_string($conn, $_POST['address']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$size = mysqli_real_escape_string($conn, $_POST['size']);
$price = mysqli_real_escape_string($conn, $_POST['price']);
$file =  $_FILES['file']['name'];
$file_tmp = $_FILES['file']['tmp_name'];
$description = mysqli_real_escape_string($conn, $_POST['description']);

        $target_dir = "assets/";
        $target_file = $target_dir . basename($file);
        //$move=move_uploaded_file($file_tmp, $target_file);

        $check_user = mysqli_query($conn, "SELECT * FROM users WHERE wallet='$wallet'");
        if(mysqli_num_rows($check_user)>0){
            if(move_uploaded_file($file_tmp, $target_file)){
                $sql = "INSERT INTO arts(user_id,`owner`, name, size, price, file, description)VALUES('$wallet','$wallet','$name','$size','$price','$target_file','$description')";
    
                $insert = mysqli_query($conn, $sql);
                
                if($insert){
                    $art_id = mysqli_insert_id($conn);
                    $array = array(
                        "success"=>true,
                        "message"=>"Artwork Uploaded successfully, Please proceed to make mint fee",
                        "id"=>$art_id
                    );
                }
                else{
                    $array = array(
                        "success"=>false,
                        "message"=>"An Error occurred why uploading your art"
                    );
                }
            }
            else{
                //$err  = mysqli_error($conn);
                $array = array(
                    "success"=>false,
                    "message"=>"An Error occurred why uploading your art "
                );
            }
        }
        else{
            $array = array(
                "success"=>false,
                "message"=>"Please create a profile before uploading an art"
            );
        }
        



//echo json_encode($_POST);
echo json_encode($array);

?>