<?php
require "variables.php";
cors();
//echo ("entries". json_encode($_POST['data']));

$data = json_encode($_POST);
//print_r($data);
$address = mysqli_real_escape_string($conn, $_POST['address']);
$to = mysqli_real_escape_string($conn, $_POST['to']);
$art = mysqli_real_escape_string($conn, $_POST['art']);
$price = mysqli_real_escape_string($conn, $_POST['price']);

$sql = "INSERT INTO bids(art, `from`, `to`, amount)VALUES('$art','$address','$to','$price')";

$sql2 = "UPDATE arts SET user_id = '$address' WHERE id='$art'";
$sql3 = "SELECT balance FROM users WHERE wallet = '$address'";
$sql4 = "SELECT balance FROM users WHERE wallet = '$to'";

$get_buyer = mysqli_query($conn, $sql3);
$get_seller = mysqli_query($conn, $sql4);

$buyer=mysqli_fetch_assoc($get_buyer);
$seller=mysqli_fetch_assoc($get_seller);

$buyer_balance = doubleval($buyer['balance']);
$seller_balance = doubleval($seller['balance']);

$new_buyer_balance = $buyer_balance-$price;
$new_seller_balance = $seller_balance+$price;

if($buyer_balance>=$price){
    $insert = mysqli_query($conn, $sql);
    $update = mysqli_query($conn, $sql2);
    $update_buyer_balance=mysqli_query($conn, "UPDATE users SET balance='$new_buyer_balance' WHERE wallet='$address'");
    
    $update_seller_balance=mysqli_query($conn, "UPDATE users SET balance='$new_seller_balance' WHERE wallet='$to'");
    
    if($insert){
        $array = array(
            "success"=>true,
            "message"=>"Purchase successful"
        );
    }
    else{
        $array = array(
            "success"=>false,
            "message"=>"An Error occurred "
        );
    }
}

else{
    $array = array(
            "success"=>false,
            "message"=>"Insufficient balance"
        );
}


//echo json_encode($_POST);
echo json_encode($array);

?>