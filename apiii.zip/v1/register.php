<?php
require "variables.php";
cors();

$fname = mysqli_real_escape_string($conn, $_POST['fname']);
$lname = mysqli_real_escape_string($conn, $_POST['lname']);
$uname = mysqli_real_escape_string($conn, $_POST['uname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$url = mysqli_real_escape_string($conn, $_POST['url']);
$wallet = mysqli_real_escape_string($conn, $_POST['address']);
$password  = mysqli_real_escape_string($conn, $_POST['password']);
$file =  $_FILES['image']['name'];
$file_tmp = $_FILES['image']['tmp_name'];
// $array=array();

$target_dir = "assets/";
$target_file = $target_dir . basename($file);

$password = password_hash($password, PASSWORD_BCRYPT);

//check for wallet address
$get_address = mysqli_query($conn, "SELECT * FROM users WHERE wallet = '$wallet'");
if(mysqli_num_rows($get_address)==0){
            //check for email
    $get_email = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
    if(mysqli_num_rows($get_email)==0){
        if(move_uploaded_file($file_tmp, $target_file)){
            $sql = "INSERT INTO users(first_name, last_name, username, url,wallet, email,image,password) VALUES('$fname','$lname','$uname','$url','$wallet','$email','$target_file','$password')";

            $insert = mysqli_query($conn, $sql);
        
            if($insert){
                $array = array(
                    "success"=>true,
                    "message"=>"Profile completed"
                );
            }
            else{
                $array = array(
                    "success"=>false,
                    "message"=>"An error occured"
                ); 
            }
            }
            else{
                $array = array(
                    "success"=>false,
                    "message"=>"Error uploading file"
                ); 
            }
           
        }
         else{
                $array = array( 
                    "success"=>false,
                    "message"=>"Email Already Exists"
                ); 
            }
       
}
else{
    $array = array(
        "success"=>false,
        "message"=>"This address is already registered with an email"
    ); 
}






echo json_encode($array);
//echo $wallet;
?>