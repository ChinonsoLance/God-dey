<?php
require "variables.php";
cors();
//echo json_encode($_POST);
$amount = mysqli_real_escape_string($conn, $_POST['price']);
$to = mysqli_real_escape_string($conn, $_POST['address']);


$get_to_details = mysqli_query($conn, "SELECT balance FROM users WHERE wallet = '$to'");
$to_details = mysqli_fetch_assoc($get_to_details);
$to_balance = $to_details['balance'];

$new_from =  $from_balance-$amount;
$new_to = $to_balance+$amount;
if(true){
   
    $update_to = mysqli_query($conn, "UPDATE users SET balance = '$new_to' WHERE wallet = '$to'");
    if($update_to){
        $array = array(
            "success"=>true,
            "message"=>""
        );
    }
    else{
        $array = array(
            "success"=>false,
            "message"=>"An error occurred "
        );
    }
}



echo json_encode($array);