<?php
require "variables.php";
cors();

$username = mysqli_real_escape_string($conn, $_POST['username']);
$fname = mysqli_real_escape_string($conn, $_POST['firstname']);
$lname = mysqli_real_escape_string($conn, $_POST['lastname']);
//$uname = mysqli_real_escape_string($conn, $_POST['uname']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$url = mysqli_real_escape_string($conn, $_POST['url']);
$bio = mysqli_real_escape_string($conn, $_POST['bio']);
$address = mysqli_real_escape_string($conn, $_POST['address']);

$update = mysqli_query($conn, "UPDATE users SET first_name = '$fname', last_name='$lname', phone='$phone', url='$url', bio='$bio' WHERE wallet = '$address'");

if($update){
    $array = array(
        "success"=>true,
        "message"=>""
    );
}
else{
    $array = array(
        "success"=>false,
        "message"=>"An error occurred while updating your profile"
    );
}

echo json_encode($array);