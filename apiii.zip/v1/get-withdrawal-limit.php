<?php
require "variables.php";
cors();



$select = mysqli_query($conn, "SELECT withdrawal_limit FROM settings WHERE id='1'");

if(mysqli_num_rows($select)>0){
    $setting = mysqli_fetch_assoc($select);
    $withdraw_limit=$setting['withdrawal_limit'];
}


echo $withdraw_limit;