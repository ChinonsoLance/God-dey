<?php
require "variables.php";
cors();
$art_id=$_REQUEST['id'];

$get_arts = mysqli_query($conn, "SELECT arts.name,arts.price, arts.file, arts.status,arts.description, arts.id, arts.user_id, users.image, users.username, arts.owner FROM arts LEFT JOIN users ON arts.user_id=users.wallet WHERE arts.id='$art_id'");
$array=array();
if(mysqli_num_rows($get_arts)>0){
    $art=mysqli_fetch_assoc($get_arts);
        $name=$art['name'];
        $price=$art['price'];
        $file=$art['file'];
        $status=$art['status'];
        $id=$art['id'];
        $user_address=$art['user_id'];
        $username =$art['username'];
        $image=$art['image'];
        $owner=$art['owner'];
        $description=$art['description'];

        $array = array(
            "status"=>$status,
            "name"=>$name,
            "price"=>$price,
            "file"=>$file,
            "id"=>$id,
            "address"=>$user_address,
            "username"=>$username,
            "owner"=>$owner,
            "image"=>$image,
            "description"=>$description
            );
            
    }
else{
    $array = array();
}

echo json_encode($array);

?>