<?php
require "variables.php";
cors();
$wallet=$_REQUEST['id'];

$get_user = mysqli_query($conn, "SELECT * FROM users WHERE wallet='$wallet'");
if(mysqli_num_rows($get_user)>0){
    $user=mysqli_fetch_assoc($get_user);

    $fname=$user['first_name'];
    $lname=$user['last_name'];
    $email=$user['email'];
    $url=$user['url'];
    $bio=$user['bio'];
    $phone=$user['phone'];
    $uname=$user['username'];
    $image=$user['image'];
    $balance = $user['balance'];

    $array = array(
        "completed"=>true,
        "firstname"=>$fname,
        "lastname"=>$lname,
        "url"=>$url,
        "bio"=>$bio,
        "phone"=>$phone,
        "username"=>$uname,
        "email"=>$email,
        "image"=>$image,
        "balance"=>$balance
    );

    
}
else{
    $array = array(
        "completed"=>false,
        );
}

echo json_encode($array);

?>