<?php
require "variables.php";
cors();

$sql = "
SELECT
b.`to`,
u.username,
u.image,
SUM(b.amount) AS total_amount_spent
FROM
bids b
JOIN
users u ON b.`to` = u.wallet
GROUP BY
b.`to`, u.username, u.image
ORDER BY
total_amount_spent DESC;
";

$get_users = mysqli_query($conn, $sql);
$total_array = [];
if(mysqli_num_rows($get_users)>0){
    while($user=mysqli_fetch_assoc($get_users)){
        $address = $user['to'];
        $username = $user['username'];
        $image = $user['image'];
        $total = $user['total_amount_spent'];
    }

    
    $array = array(
        "username"=>$username,
        "address"=>$address,
        "image"=>$image,
        "total"=>$total,
        );

    array_push($total_array, $array);
}
else{
    $array = array(
        
        );
}

echo json_encode($total_array);

?>