<?php
require "variables.php";
cors();

$file =  $_FILES['image']['name'];
$file_tmp = $_FILES['image']['tmp_name'];
$address=$_POST['address'];

$target_dir = "assets/";
$target_file = $target_dir . basename($file);

if(move_uploaded_file($file_tmp, $target_file)){
    $update=mysqli_query($conn, "UPDATE users SET image='$target_file' WHERE wallet='$address'");
}
?>