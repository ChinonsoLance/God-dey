<?php
require "variables.php";
cors();

$address = mysqli_real_escape_string($conn,$_POST['address']);
$fee = mysqli_real_escape_string($conn,$_POST['fee']);


$update = mysqli_query($conn, "INSERT INTO transactions(user_id, amount)VALUES('$address','$fee')");

if($update){
    $array = array(
        "success"=>true,
        "message"=>""
    );
}
else{
    $array = array(
        "success"=>false,
        "message"=>"An error occurred"
    );
}

echo json_encode($array);