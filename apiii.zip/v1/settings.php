<?php
require "variables.php";
cors();

$get_settings = mysqli_query($conn, "SELECT * FROM settings WHERE id='1'");
$array=array();
if(mysqli_num_rows($get_settings)>0){
    $setting=mysqli_fetch_assoc($get_settings);
        $mint=$setting['mint_fee'];
       

        $array = array(
            "mint_fee"=>$mint,
            
            );
            
    }
else{
    $array = array();
}

echo json_encode($array);

?>