<?php
require "variables.php";
cors();

$get_arts = mysqli_query($conn, "SELECT arts.id,arts.name, arts.price, arts.user_id, arts.file, arts.status, users.username, users.wallet, users.image FROM arts LEFT JOIN users ON arts.user_id = users.wallet WHERE arts.status='approved' ORDER BY id DESC");
$full_array=array();
if(mysqli_num_rows($get_arts)>0){
    while($art=mysqli_fetch_assoc($get_arts)){
        $name=$art['name'];
        $price=$art['price'];
        $file=$art['file'];
        $status=$art['status'];
        $id=$art['id'];
        $wallet=$art['wallet'];
        $username=$art['username'];
        $image = $art['image'];
        

        $array = array(
            "status"=>$status,
            "name"=>$name,
            "price"=>$price,
            "file"=>$file,
            "id"=>$id,
            "wallet"=>$wallet,
            "username"=>$username,
            "image"=>$image
            );
            array_push($full_array, $array);
    }
    
   

    
}
else{
    $full_array = array();
}

echo json_encode($full_array);

?>