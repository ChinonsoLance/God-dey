<?php
require "variables.php";
cors();

$art = $_POST['art'];


$update = mysqli_query($conn, "UPDATE arts SET status = 'pending' WHERE id = '$art'");

if($update){
    $array = array(
        "success"=>true,
        "message"=>""
    );
}
else{
    $array = array(
        "success"=>false,
        "message"=>"An error occurred"
    );
}

echo json_encode($array);